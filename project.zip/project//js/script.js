                    const user = "gadzala";
                    const pass = "123";
                    
                    if (localStorage.getItem("LoginUser")) {
                        showWelcome(localStorage.getItem("LoginUser"));
                    }
                    
            
                    
                    function login() {
                        const unsername = document.getElementById("username").value;
                        const password = document.getElementById("password").value;
                        const errorMsg = document.getElementById("errorMsg");
                    
                    
                        if (!uname || !pwd) {
                            errorMsg.textContent = "Username dan password wajib diisi."
                            errorMsg.classList.remove("hidden")
                            retun;
                        }
                        
                        if (uname === user && pwd === pass) { 
                            localStorage.setitem("loginUser", uname);
                            showWelcome(uname);
                        } else { 
                            errorMsg.textContent "Username atau password salah"; 
                            errorMsg.classList.remove("hidden");
                        }
                    }
                        function logout() {
                            localStorage.removeltem("loginUser"); 
                            document.getElementById("loginBox").classList.remove("hidden"); 
                            document.getElementById("welcomeBox").classList.add("hidden"); 
                            document.getElementById("errorMsg").classList.add("hidden"); 
                            document.getElementById("username").value = ""; 
                            document.getElementById("password").value"";

                        function showWelcome(name) { 
                            document.getElementById("loginBox").classList.add("hidden"); 
                            document.getElementById("welcomeBox").classList.remove("hidden"); 
                            document.getElementById("welcomeUser").textContent = 'Halo, ${name}';
                            
                        }